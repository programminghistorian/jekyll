# -*- coding: utf-8 -*-
##################################################
# This just creates a text file to feed to wget   #
# Not generic at all but built for 1830s trials  #
##################################################

mainoutdirname = '../baileyfiles/'

wgets = ''
for x in range(0,22711,10):
    getline = 'http://www.oldbaileyonline.org/obapi/ob?term0=fromdate_18300114&term1=todate_18391216&count=10&start=' + str(x+1) + '&return=zip\n'
    wgets += getline
    
filename = mainoutdirname + 'wget1830s.txt'
with open(filename,'w') as f:
    f.write(wgets)