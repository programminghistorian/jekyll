# hello-world.py
print 'hello world'