**Harvard**
M. H. Beals. (2015). Scissors and Paste Core Dataset and Derived Data v1.0.0. Zenodo. 10.5281/zenodo.33682

**Chicago**
M. H. Beals *Scissors and Paste Core Dataset and Derived Data* v1.0.0. (Zenodo, 2015). DOI:10.5281/zenodo.33682
