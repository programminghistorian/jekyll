Scissors & Paste
===========================

A collection of transcriptions from British newspapers (1789-1850) alongside originals from colonial and American newspapers, where relevant.

#### Contributors

+ Compiled by M. H. Beals (*Loughborough University*)
+ Contributions by Max Templer (*University of Sheffield*)

If you would like to contribute, please contact [the compiler] (mailto:m.h.beals@lboro.ac.uk)

