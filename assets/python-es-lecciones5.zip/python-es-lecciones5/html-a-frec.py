#html-a-frec.py

import urllib2, obo

url = 'http://www.oldbaileyonline.org/browse.jsp?id=t17800628-33&div=t17800628-33'

respuesta = urllib2.urlopen(url)
html = respuesta.read()
texto = obo.quitarEtiquetas(html).lower()
listaPalabras = obo.quitaNoAlfaNum(texto)
diccionario = obo.listaPalabrasDicFrec(listaPalabras)
diccOrdenado = obo.ordenaDicFrec(diccionario)

for s in diccOrdenado: print(str(s))

