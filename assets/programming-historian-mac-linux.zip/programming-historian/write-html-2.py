# write-html-2.py mac
 
import webbrowser
 
f = open('helloworld.html','w')
 
message = """<html>
<head></head>
<body><p>Hello World!</p></body>
</html>"""
 
f.write(message)
f.close()

#Change path to reflect file location
filename = 'file:///Users/username/Desktop/programming-historian/' + 'helloworld.html'
webbrowser.open_new_tab(filename)