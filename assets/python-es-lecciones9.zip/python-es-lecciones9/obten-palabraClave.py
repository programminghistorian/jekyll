#obten-palabraClave.py

import obo

prueba = 'en la frase de prueba hay ocho palabras'
ngramas = obo.obtenNGramas(prueba.split(), 5)

print(obo.nGramasAdicKWIC(ngramas))