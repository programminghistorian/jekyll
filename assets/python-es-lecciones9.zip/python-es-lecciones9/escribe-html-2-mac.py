# escribe-html-2-mac.py
import webbrowser

f = open('holamundo.html','w')

mensaje = """<html>
<head></head>
<body><p>Hola Mundo!</p></body>
</html>"""

f.write(mensaje)
f.close()

#Cambia la ruta para indicar la localización del archivo
nombreArchivo = 'file:///Users/username/Desktop/programming-historian/' + 'holamundo.html'
webbrowser.open_new_tab(nombreArchivo)

