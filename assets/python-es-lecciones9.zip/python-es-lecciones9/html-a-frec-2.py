# html-a-frec-2.py

import urllib2
import obo

url = 'http://www.oldbaileyonline.org/browse.jsp?id=t17800628-33&div=t17800628-33'

respuesta = urllib2.urlopen(url)
html = respuesta.read()
texto = obo.quitarEtiquetas(html).lower()
listaPalabrasCompleta = obo.quitaNoAlfaNum(texto)
listaPalabras = obo.quitarPalabrasvac(listaPalabrasCompleta, obo.palabrasvac)
diccionario = obo.listaPalabrasDicFrec(listaPalabras)
diccOrdenado = obo.ordenaDicFrec(diccionario)

for s in diccOrdenado: print(str(s))

