# file-append.py
f = open('helloworld.txt','a')
f.write('\n' + 'hello world')
f.close()