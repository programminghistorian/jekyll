# greet.py

def greetEntity (x):
    print "hello " + x