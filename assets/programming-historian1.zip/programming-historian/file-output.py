# file-output.py
f = open('helloworld.txt','w')
f.write('hello world')
f.close()