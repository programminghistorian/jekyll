# file-input.py
f = open('helloworld.txt','r')
message = f.read()
print message
f.close()