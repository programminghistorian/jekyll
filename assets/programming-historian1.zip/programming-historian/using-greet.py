# using-greet.py

import greet
greet.greetEntity("everybody")
greet.greetEntity("programming historian")