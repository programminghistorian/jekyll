# usaobtenNGramas.py

import obo

cadenaPalabras = 'it was the best of times it was the worst of times '
cadenaPalabras += 'it was the age of wisdom it was the age of foolishness'
todasMisPalabras = cadenaPalabras.split()

print(obo.obtenNGramas(todasMisPalabras, 5))