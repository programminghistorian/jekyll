# obo.py

def quitarEtiquetas(contenidoPagina):
    contenidoPagina = str(contenidoPagina)
    lugarInicio = contenidoPagina.find("<p>")
    lugarFin = contenidoPagina.rfind("<br/>")

    contenidoPagina = contenidoPagina[lugarInicio:lugarFin]
    return contenidoPagina